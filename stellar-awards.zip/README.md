# Stellar Awards – Nomination Page

Angular 17+ (standalone) + Bootstrap 5 + Bootstrap Icons.

## Setup
1. `ng new stellar --standalone --style=scss --routing=false`
2. Install router is included by default. Copy the `src/` files from this folder over the generated ones.
3. `ng serve`
