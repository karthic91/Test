import { bootstrapApplication } from '@angular/platform-browser';
import { NominationComponent } from './app/nomination.component';

bootstrapApplication(NominationComponent).catch(err => console.error(err));
