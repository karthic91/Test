import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';

interface Colleague {
  initials: string; name: string; title: string; dept: string; badge: string; special?: boolean;
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  userName = 'Robert';
  search = '';

  colleagues: Colleague[] = [
    { initials: 'AR', name: 'Ananya Rao', title: 'Senior Software Engineer', dept: 'Technology', badge: 'Eligible' },
    { initials: 'RM', name: 'Rahul Mehta', title: 'Engineering Lead', dept: 'Technology', badge: 'Eligible' },
    { initials: 'PN', name: 'Priya Nair', title: 'Business Analyst', dept: 'Operations', badge: 'Eligible' },
    { initials: 'VS', name: 'Vikram Shah', title: 'People Manager', dept: 'Technology', badge: 'LODESTAR eligible', special: true }
  ];

  activity = [
    { label: 'Submitted', value: 2, icon: 'bi-file-earmark-text' },
    { label: 'Draft', value: 1, icon: 'bi-file-earmark-text' },
    { label: 'Available', value: 2, icon: 'bi-clock' }
  ];
  used = 3;
  total = 5;

  get usedPct() { return Math.round((this.used / this.total) * 100); }

  get filtered() {
    const q = this.search.trim().toLowerCase();
    return q ? this.colleagues.filter(c => (c.name + c.title + c.dept).toLowerCase().includes(q)) : this.colleagues;
  }
}
