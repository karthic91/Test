import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

type AwardType = 'team' | 'individual';

interface Employee { id: string; name: string; dept: string; bu: string; title: string; }

@Component({
  selector: 'app-nomination',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './nomination.component.html',
  styleUrls: ['./nomination.component.scss']
})
export class NominationComponent {
  steps = [
    { no: 1, label: 'Details' },
    { no: 2, label: 'Review' },
    { no: 3, label: 'Submit' }
  ];
  currentStep = 1;
  maxLen = 1000;

  employees: Employee[] = [
    { id: 'EMP-2048', name: 'Ananya Rao', dept: 'Technology', bu: 'CIB – Technology', title: 'Senior Software Engineer' },
    { id: 'EMP-2051', name: 'Rahul Mehta', dept: 'Operations', bu: 'CIB – Operations', title: 'Operations Manager' },
    { id: 'EMP-2064', name: 'Priya Nair', dept: 'Design', bu: 'CIB – Technology', title: 'UX Designer' },
    { id: 'EMP-2070', name: 'Karan Shah', dept: 'Risk', bu: 'CIB – Risk', title: 'Risk Analyst' }
  ];
  businessUnits = ['CIB – Technology', 'CIB – Operations', 'CIB – Risk'];
  titles = ['Senior Software Engineer', 'Operations Manager', 'UX Designer', 'Risk Analyst'];
  periods = ['Q2 2026 · April – June', 'Q1 2026 · January – March'];

  categories: Record<AwardType, { name: string; desc: string }[]> = {
    team: [{ name: 'ORION', desc: 'Quarterly award for teams' }],
    individual: [
      { name: 'ANTARES', desc: 'Quarterly award for individuals' },
      { name: 'LODESTAR', desc: 'Quarterly award for People Managers' },
      { name: 'RISING STAR', desc: 'Monthly award for individuals' }
    ]
  };

  form = this.blank('team');

  private blank(type: AwardType) {
    return {
      type,
      teamName: type === 'team' ? 'People Experience Champions' : '',
      members: type === 'team' ? ['Ananya Rao', 'Rahul Mehta', 'Priya Nair'] : ([] as string[]),
      nominee: type === 'individual' ? 'Ananya Rao' : '',
      bu: type === 'individual' ? 'CIB – Technology' : '',
      title: type === 'individual' ? 'Senior Software Engineer' : '',
      period: this.periods[0],
      category: type === 'team' ? 'ORION' : 'ANTARES',
      reason: ''
    };
  }

  setType(type: AwardType) {
    if (this.form.type !== type) this.form = this.blank(type);
  }

  get availableMembers() {
    return this.employees.filter(e => !this.form.members.includes(e.name));
  }
  addMember(name: string) {
    if (name && !this.form.members.includes(name)) this.form.members.push(name);
  }
  removeMember(name: string) {
    this.form.members = this.form.members.filter(m => m !== name);
  }

  get nominee(): Employee | undefined {
    return this.employees.find(e => e.name === this.form.nominee);
  }
  onNomineeChange() {
    const n = this.nominee;
    if (n) { this.form.bu = n.bu; this.form.title = n.title; }
  }

  get categoryDesc() {
    return this.categories[this.form.type].find(c => c.name === this.form.category)?.desc ?? '';
  }

  get completion(): number {
    const f = this.form;
    const checks = f.type === 'team'
      ? [f.teamName, f.members.length, f.period, f.category, f.reason]
      : [f.nominee, f.bu, f.title, f.period, f.category, f.reason];
    const done = checks.filter(v => !!v).length;
    return Math.round((done / checks.length) * 100);
  }

  clear() {
    const t = this.form.type;
    this.form = { ...this.blank(t), teamName: '', members: [], nominee: '', bu: '', title: '', category: '' };
  }
  saveDraft() { console.log('Draft saved', this.form); }
  continue() { if (this.currentStep < 3) this.currentStep++; console.log(this.form); }
}
