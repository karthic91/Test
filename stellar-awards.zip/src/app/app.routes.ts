import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { NominationComponent } from './nomination.component';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'nomination', component: NominationComponent },
  { path: '**', redirectTo: '' }
];
